import { useState, useCallback } from "react";
import { ScrollView, Text, View, ActivityIndicator, RefreshControl } from "react-native";
import { useFocusEffect } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import * as LocalStore from "@/lib/local-store";

export default function ReportsScreen() {
  const colors = useColors();
  const [refreshing, setRefreshing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [dashboardStats, setDashboardStats] = useState<LocalStore.DashboardStats | null>(null);
  const [clientsByServer, setClientsByServer] = useState<any[]>([]);

  const loadData = useCallback(async () => {
    try {
      setIsLoading(true);
      const stats = await LocalStore.getDashboardStats();
      const serverData = await LocalStore.getClientsByServer();
      setDashboardStats(stats);
      setClientsByServer(serverData);
    } catch (error) {
      console.error("Error loading reports:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  if (isLoading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color={colors.primary} />
      </ScreenContainer>
    );
  }

  const mrr = dashboardStats?.monthlyRecurringRevenue || 0;
  const mrc = dashboardStats?.monthlyRecurringCost || 0;
  const profit = dashboardStats?.monthlyNetProfit || 0;
  const projectedAnnualRevenue = mrr * 12;
  const projectedAnnualProfit = profit * 12;

  return (
    <ScreenContainer className="px-4 pt-4">
      <ScrollView
        contentContainerStyle={{ paddingBottom: 150 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
      >
        <Text className="text-3xl font-bold text-foreground mb-6">
          Relatórios Financeiros
        </Text>

        {/* Métricas Principais */}
        <View className="mb-6">
          <Text className="text-lg font-semibold text-foreground mb-3">
            Visão Geral
          </Text>

          <View className="bg-surface rounded-2xl p-4 mb-3 border border-border">
            <Text className="text-sm text-muted mb-1">
              Receita Mensal Recorrente (MRR)
            </Text>
            <Text className="text-3xl font-bold text-primary">
              {formatCurrency(mrr)}
            </Text>
            <Text className="text-xs text-muted mt-1">
              Projeção anual: {formatCurrency(projectedAnnualRevenue)}
            </Text>
          </View>

          <View className="bg-surface rounded-2xl p-4 mb-3 border border-border">
            <Text className="text-sm text-muted mb-1">
              Custo Mensal Recorrente (MRC)
            </Text>
            <Text className="text-3xl font-bold text-error">
              {formatCurrency(mrc)}
            </Text>
            <Text className="text-xs text-muted mt-1">
              Projeção anual: {formatCurrency(mrc * 12)}
            </Text>
          </View>

          <View className="bg-surface rounded-2xl p-4 mb-3 border border-border">
            <Text className="text-sm text-muted mb-1">
              Lucro Líquido Mensal
            </Text>
            <Text className="text-3xl font-bold text-success">
              {formatCurrency(profit)}
            </Text>
            <Text className="text-xs text-muted mt-1">
              Projeção anual: {formatCurrency(projectedAnnualProfit)}
            </Text>
          </View>

          <View className="flex-row gap-3">
            <View className="flex-1 bg-surface rounded-2xl p-4 border border-border">
              <Text className="text-sm text-muted mb-1">Clientes Ativos</Text>
              <Text className="text-2xl font-bold text-foreground">
                {dashboardStats?.totalActiveClients || 0}
              </Text>
            </View>

            <View className="flex-1 bg-surface rounded-2xl p-4 border border-border">
              <Text className="text-sm text-muted mb-1">Vencem em 7 dias</Text>
              <Text className="text-2xl font-bold text-warning">
                {dashboardStats?.expiringThisWeek || 0}
              </Text>
            </View>
          </View>
        </View>

        {/* Distribuição por Servidor */}
        <View className="mb-6">
          <Text className="text-lg font-semibold text-foreground mb-3">
            Distribuição por Servidor
          </Text>

          {clientsByServer && clientsByServer.length > 0 ? (
            clientsByServer.map((item, index) => {
              const totalRevenue = item.totalRevenue || 0;
              const totalCost = item.totalCost || 0;
              const serverProfit = item.profit || 0;
              const percentage = mrr > 0 ? (totalRevenue / mrr) * 100 : 0;

              return (
                <View
                  key={index}
                  className="bg-surface rounded-2xl p-4 mb-3 border border-border"
                >
                  <View className="flex-row items-center justify-between mb-2">
                    <Text className="text-base font-semibold text-foreground flex-1">
                      {item.server}
                    </Text>
                    <Text className="text-sm font-medium text-primary">
                      {percentage.toFixed(1)}%
                    </Text>
                  </View>

                  <View className="flex-row items-center justify-between mb-2">
                    <Text className="text-sm text-muted">
                      {item.count} {item.count === 1 ? "cliente" : "clientes"}
                    </Text>
                    <Text className="text-sm font-medium text-foreground">
                      {formatCurrency(totalRevenue)}/mês
                    </Text>
                  </View>

                  <View className="flex-row justify-between mb-2">
                    <Text className="text-xs text-muted">Custo:</Text>
                    <Text className="text-xs text-error font-medium">
                      {formatCurrency(totalCost)}
                    </Text>
                  </View>

                  <View className="flex-row justify-between">
                    <Text className="text-xs text-muted">Lucro:</Text>
                    <Text className="text-xs text-success font-medium">
                      {formatCurrency(serverProfit)}
                    </Text>
                  </View>

                  <View className="mt-3 h-2 bg-border rounded-full overflow-hidden">
                    <View
                      className="h-full rounded-full"
                      style={{
                        width: `${percentage}%`,
                        backgroundColor: colors.primary,
                      }}
                    />
                  </View>
                </View>
              );
            })
          ) : (
            <View className="bg-surface rounded-2xl p-6 border border-border items-center">
              <Text className="text-muted text-center">
                Nenhum dado disponível. Adicione clientes para ver relatórios.
              </Text>
            </View>
          )}
        </View>

        {/* Resumo Financeiro */}
        <View className="mb-6">
          <Text className="text-lg font-semibold text-foreground mb-3">
            Resumo Financeiro
          </Text>

          <View className="bg-surface rounded-2xl p-4 border border-border">
            <View className="flex-row items-center justify-between py-2">
              <Text className="text-sm text-foreground">Receita Mensal</Text>
              <Text className="text-sm font-semibold text-primary">
                {formatCurrency(mrr)}
              </Text>
            </View>

            <View
              className="flex-row items-center justify-between py-2"
              style={{ borderTopWidth: 1, borderTopColor: colors.border }}
            >
              <Text className="text-sm text-foreground">Custo Mensal</Text>
              <Text className="text-sm font-semibold text-error">
                {formatCurrency(mrc)}
              </Text>
            </View>

            <View
              className="flex-row items-center justify-between py-2"
              style={{ borderTopWidth: 1, borderTopColor: colors.border }}
            >
              <Text className="text-sm font-semibold text-foreground">Lucro Líquido</Text>
              <Text className="text-sm font-bold text-success">
                {formatCurrency(profit)}
              </Text>
            </View>

            {mrr > 0 && (
              <View
                className="flex-row items-center justify-between py-2"
                style={{ borderTopWidth: 1, borderTopColor: colors.border }}
              >
                <Text className="text-sm text-muted">Margem de Lucro</Text>
                <Text className="text-sm font-semibold text-success">
                  {((profit / mrr) * 100).toFixed(1)}%
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Insights */}
        <View className="mb-6">
          <Text className="text-lg font-semibold text-foreground mb-3">
            Insights
          </Text>

          <View className="bg-primary/10 rounded-2xl p-4 border border-primary/20">
            <Text className="text-sm text-foreground mb-2">
              💡 <Text className="font-semibold">Dica:</Text>
            </Text>
            <Text className="text-sm text-foreground leading-relaxed">
              Você tem {dashboardStats?.expiringThisWeek || 0} clientes com
              vencimento nos próximos 7 dias. Entre em contato para garantir a
              renovação e manter sua receita estável.
            </Text>
          </View>

          {dashboardStats && dashboardStats.expiredClients > 0 && (
            <View className="bg-error/10 rounded-2xl p-4 border border-error/20 mt-3">
              <Text className="text-sm text-foreground mb-2">
                ⚠️ <Text className="font-semibold">Atenção:</Text>
              </Text>
              <Text className="text-sm text-foreground leading-relaxed">
                Você tem {dashboardStats.expiredClients}{" "}
                {dashboardStats.expiredClients === 1 ? "cliente vencido" : "clientes vencidos"}.
                Considere entrar em contato para renovação ou desativar o serviço.
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
