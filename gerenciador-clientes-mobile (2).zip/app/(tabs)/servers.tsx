import { useState, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  Alert,
} from "react-native";
import { useFocusEffect } from "expo-router";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { AddModal } from "@/components/add-modal";
import * as LocalStore from "@/lib/local-store";

export default function ServersScreen() {
  const colors = useColors();
  const [servers, setServers] = useState<LocalStore.Server[]>([]);
  const [clients, setClients] = useState<LocalStore.Client[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const [serversData, clientsData] = await Promise.all([
        LocalStore.getServers(),
        LocalStore.getClients(),
      ]);
      setServers(serversData);
      setClients(clientsData);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const handleDelete = (server: LocalStore.Server) => {
    const serverClients = clients.filter((c) => c.server === server.name);
    if (serverClients.length > 0) {
      Alert.alert(
        "Não é possível excluir",
        `Este servidor possui ${serverClients.length} cliente(s) vinculado(s).`
      );
      return;
    }

    Alert.alert(
      "Excluir Servidor",
      `Tem certeza que deseja excluir ${server.name}?`,
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Excluir",
          style: "destructive",
          onPress: async () => {
            await LocalStore.deleteServer(server.id);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            loadData();
          },
        },
      ]
    );
  };

  const getServerStats = (server: LocalStore.Server) => {
    const serverClients = clients.filter((c) => c.server === server.name);
    const totalRevenue = serverClients.reduce(
      (sum, c) => sum + (parseFloat(c.monthlyCost) || 0),
      0
    );
    const totalCost = serverClients.length * parseFloat(server.costPerClient);
    const profit = totalRevenue - totalCost;

    return {
      clientCount: serverClients.length,
      totalRevenue,
      totalCost,
      profit,
    };
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  const renderServer = ({ item }: { item: LocalStore.Server }) => {
    const stats = getServerStats(item);

    return (
      <View className="bg-surface rounded-xl p-4 mb-3 border border-border">
        <View className="flex-row justify-between items-start mb-3">
          <View className="flex-1">
            <Text className="text-foreground font-semibold text-lg">
              {item.name}
            </Text>
            {item.description && (
              <Text className="text-muted text-sm">{item.description}</Text>
            )}
          </View>
          <TouchableOpacity
            className="bg-error/20 px-3 py-1 rounded-lg"
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
              handleDelete(item);
            }}
          >
            <Text className="text-error text-xs font-medium">Excluir</Text>
          </TouchableOpacity>
        </View>

        <View className="flex-row gap-2 mb-3">
          <View className="flex-1 bg-background rounded-lg p-3">
            <Text className="text-muted text-xs">Clientes</Text>
            <Text className="text-foreground font-bold text-lg">
              {stats.clientCount}
            </Text>
          </View>
          <View className="flex-1 bg-background rounded-lg p-3">
            <Text className="text-muted text-xs">Custo/Cliente</Text>
            <Text className="text-foreground font-bold text-lg">
              {formatCurrency(parseFloat(item.costPerClient))}
            </Text>
          </View>
        </View>

        <View className="flex-row gap-2">
          <View className="flex-1 bg-background rounded-lg p-3">
            <Text className="text-muted text-xs">Receita</Text>
            <Text className="text-success font-bold">
              {formatCurrency(stats.totalRevenue)}
            </Text>
          </View>
          <View className="flex-1 bg-background rounded-lg p-3">
            <Text className="text-muted text-xs">Lucro</Text>
            <Text
              className="font-bold"
              style={{ color: stats.profit >= 0 ? colors.success : colors.error }}
            >
              {formatCurrency(stats.profit)}
            </Text>
          </View>
        </View>
      </View>
    );
  };

  return (
    <ScreenContainer className="px-4 pt-4">
      <View className="mb-4">
        <Text className="text-3xl font-bold text-foreground mb-2">
          Servidores
        </Text>
        <Text className="text-sm text-muted">
          {servers.length} servidor(es) cadastrado(s)
        </Text>
      </View>

      <FlatList
        data={servers}
        renderItem={renderServer}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={{ paddingBottom: 100 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
        ListEmptyComponent={
          <View className="items-center py-12">
            <IconSymbol name="server.rack" size={48} color={colors.muted} />
            <Text className="text-muted text-center mt-4">
              Nenhum servidor cadastrado
            </Text>
            <Text className="text-muted text-center text-sm mt-1">
              Toque no botão + para adicionar
            </Text>
          </View>
        }
      />

      <TouchableOpacity
        className="absolute bottom-24 right-4 w-14 h-14 rounded-full items-center justify-center shadow-lg"
        style={{ backgroundColor: colors.primary, elevation: 8 }}
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          setShowAddModal(true);
        }}
      >
        <IconSymbol name="plus.circle.fill" size={32} color="#fff" />
      </TouchableOpacity>

      <AddModal
        visible={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSuccess={() => loadData()}
      />
    </ScreenContainer>
  );
}
