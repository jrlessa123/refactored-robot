import { useState, useCallback } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Platform,
} from "react-native";
import { useFocusEffect } from "expo-router";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { AddModal } from "@/components/add-modal";
import * as LocalStore from "@/lib/local-store";

export default function HomeScreen() {
  const colors = useColors();
  const [showAddModal, setShowAddModal] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState<LocalStore.DashboardStats>({
    totalActiveClients: 0,
    monthlyRecurringRevenue: 0,
    monthlyRecurringCost: 0,
    monthlyNetProfit: 0,
    expiringThisWeek: 0,
    expiredClients: 0,
    costsPerServer: [],
  });

  const loadStats = useCallback(async () => {
    try {
      const data = await LocalStore.getDashboardStats();
      console.log("Dashboard Stats:", data);
      setStats(data);
    } catch (error) {
      console.error("Error loading stats:", error);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadStats();
    }, [loadStats])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await loadStats();
    setRefreshing(false);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  return (
    <ScreenContainer className="px-4 pt-4">
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingBottom: 150 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
      >
        {/* Header */}
        <View className="mb-6">
          <Text className="text-3xl font-bold text-foreground mb-2">
            Dashboard
          </Text>
          <Text className="text-sm text-muted">
            Visão geral do seu negócio
          </Text>
        </View>

        {/* Lucro Líquido Card */}
        <View
          className="rounded-2xl p-6 mb-6"
          style={{ backgroundColor: colors.success }}
        >
          <Text className="text-white/80 text-sm mb-1">
            Lucro Líquido Mensal
          </Text>
          <Text className="text-white text-4xl font-bold mb-2">
            {formatCurrency(stats.monthlyNetProfit)}
          </Text>
          <Text className="text-white/70 text-sm">
            Projeção anual: {formatCurrency(stats.monthlyNetProfit * 12)}
          </Text>
        </View>

        {/* Revenue & Cost Cards */}
        <View className="flex-row gap-3 mb-6">
          <View className="flex-1 bg-surface rounded-xl p-4 border border-border">
            <Text className="text-muted text-xs mb-1">Receita Mensal</Text>
            <Text className="text-primary text-xl font-bold">
              {formatCurrency(stats.monthlyRecurringRevenue)}
            </Text>
          </View>

          <View className="flex-1 bg-surface rounded-xl p-4 border border-border">
            <Text className="text-muted text-xs mb-1">Custo Mensal</Text>
            <Text className="text-error text-xl font-bold">
              {formatCurrency(stats.monthlyRecurringCost)}
            </Text>
          </View>
        </View>

        {/* Costs per Server Dashboard */}
        {stats.costsPerServer.length > 0 && (
          <View className="mb-6">
            <Text className="text-foreground font-bold text-lg mb-3">
              Custos por Servidor
            </Text>
            <View className="bg-surface rounded-xl border border-border overflow-hidden">
              {stats.costsPerServer.map((item, index) => (
                <View
                  key={item.name}
                  className={`flex-row justify-between items-center p-4 ${
                    index !== stats.costsPerServer.length - 1
                      ? "border-b border-border"
                      : ""
                  }`}
                >
                  <Text className="text-foreground font-medium">{item.name}</Text>
                  <View className="items-end">
                    <Text className="text-error font-bold">
                      {formatCurrency(item.cost)}
                    </Text>
                    <Text className="text-muted text-[10px]">
                      Recarregar créditos
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Stats Grid */}
        <View className="flex-row gap-3 mb-6">
          <View className="flex-1 bg-surface rounded-xl p-4 border border-border">
            <Text className="text-muted text-xs mb-1">Clientes Ativos</Text>
            <Text className="text-foreground text-2xl font-bold">
              {stats.totalActiveClients}
            </Text>
          </View>

          <View className="flex-1 bg-surface rounded-xl p-4 border border-border">
            <Text className="text-muted text-xs mb-1">Vencem em 7d</Text>
            <Text
              className="text-2xl font-bold"
              style={{
                color:
                  stats.expiringThisWeek > 0 ? colors.warning : colors.success,
              }}
            >
              {stats.expiringThisWeek}
            </Text>
          </View>
        </View>

        {/* Expired Alert */}
        {stats.expiredClients > 0 && (
          <View className="bg-error/10 border border-error/30 rounded-xl p-4 mb-6">
            <View className="flex-row items-center gap-2 mb-2">
              <IconSymbol
                name="exclamationmark.triangle.fill"
                size={20}
                color={colors.error}
              />
              <Text className="text-error font-semibold">Atenção</Text>
            </View>
            <Text className="text-foreground text-sm">
              Você tem {stats.expiredClients} cliente(s) com vencimento expirado.
            </Text>
          </View>
        )}

        {/* Quick Tips */}
        <View className="bg-surface rounded-xl p-4 border border-border">
          <View className="flex-row items-center gap-2 mb-2">
            <Text className="text-lg">💡</Text>
            <Text className="text-foreground font-semibold">Dica do Dia:</Text>
          </View>
          <Text className="text-sm text-foreground leading-relaxed">
            Mantenha contato regular com seus clientes para garantir renovações e
            identificar oportunidades de expansão de serviços.
          </Text>
        </View>
      </ScrollView>

      <TouchableOpacity
        className="absolute bottom-24 right-4 w-14 h-14 rounded-full items-center justify-center shadow-lg"
        style={{
          backgroundColor: colors.primary,
          elevation: 8,
          marginBottom: Platform.OS === "android" ? 10 : 0,
        }}
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          setShowAddModal(true);
        }}
      >
        <IconSymbol name="plus.circle.fill" size={32} color="#fff" />
      </TouchableOpacity>

      <AddModal
        visible={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSuccess={() => loadStats()}
      />
    </ScreenContainer>
  );
}
