import { useState, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  TextInput,
  RefreshControl,
  Alert,
} from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { AddModal } from "@/components/add-modal";
import * as LocalStore from "@/lib/local-store";

type FilterStatus = "all" | "active" | "expiring" | "expired";

export default function ClientsScreen() {
  const colors = useColors();
  const router = useRouter();
  const [clients, setClients] = useState<LocalStore.Client[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState<FilterStatus>("all");
  const [showAddModal, setShowAddModal] = useState(false);

  const loadClients = useCallback(async () => {
    try {
      const data = await LocalStore.getClients();
      setClients(data);
    } catch (error) {
      console.error("Error loading clients:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadClients();
    }, [loadClients])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await loadClients();
    setRefreshing(false);
  };

  const handleDelete = (client: LocalStore.Client) => {
    Alert.alert(
      "Excluir Cliente",
      `Tem certeza que deseja excluir ${client.name}?`,
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Excluir",
          style: "destructive",
          onPress: async () => {
            await LocalStore.deleteClient(client.id);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            loadClients();
          },
        },
      ]
    );
  };

  const getClientStatus = (client: LocalStore.Client) => {
    const now = new Date();
    const expDate = new Date(client.expirationDate);
    const daysUntilExpiry = Math.ceil(
      (expDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
    );

    if (daysUntilExpiry < 0) return "expired";
    if (daysUntilExpiry <= 7) return "expiring";
    return "active";
  };

  const filteredClients = clients.filter((client) => {
    const matchesSearch = client.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const status = getClientStatus(client);

    if (filterStatus === "all") return matchesSearch;
    return matchesSearch && status === filterStatus;
  });

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("pt-BR");
  };

  const formatCurrency = (value: string) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(parseFloat(value) || 0);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return colors.success;
      case "expiring":
        return colors.warning;
      case "expired":
        return colors.error;
      default:
        return colors.muted;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active":
        return "Ativo";
      case "expiring":
        return "Vencendo";
      case "expired":
        return "Vencido";
      default:
        return status;
    }
  };

  const renderClient = ({ item }: { item: LocalStore.Client }) => {
    const status = getClientStatus(item);
    return (
      <TouchableOpacity
        className="bg-surface rounded-xl p-4 mb-3 border border-border"
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          router.push(`/client/${item.id}`);
        }}
      >
        <View className="flex-row justify-between items-start mb-2">
          <View className="flex-1">
            <Text className="text-foreground font-semibold text-lg">
              {item.name}
            </Text>
            <Text className="text-muted text-sm">{item.server}</Text>
          </View>
          <View
            className="px-2 py-1 rounded-full"
            style={{ backgroundColor: getStatusColor(status) + "20" }}
          >
            <Text
              className="text-xs font-medium"
              style={{ color: getStatusColor(status) }}
            >
              {getStatusLabel(status)}
            </Text>
          </View>
        </View>

        <View className="flex-row justify-between items-center">
          <View className="flex-row items-center gap-4">
            <View className="flex-row items-center gap-1">
              <IconSymbol name="tv.fill" size={14} color={colors.muted} />
              <Text className="text-muted text-sm">{item.screenCount}</Text>
            </View>
            <View
              className="px-2 py-0.5 rounded"
              style={{ backgroundColor: colors.primary + "20" }}
            >
              <Text
                className="text-xs font-medium"
                style={{ color: colors.primary }}
              >
                {item.clientType}
              </Text>
            </View>
          </View>
          <Text className="text-foreground font-semibold">
            {formatCurrency(item.monthlyCost)}
          </Text>
        </View>

        <View className="flex-row items-center justify-between mt-3">
          <View className="flex-row items-center gap-1">
            <IconSymbol name="calendar" size={12} color={colors.muted} />
            <Text className="text-muted text-xs">
              Vence: {formatDate(item.expirationDate)}
            </Text>
          </View>
          <TouchableOpacity
            className="bg-error/20 px-3 py-1 rounded-lg"
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
              handleDelete(item);
            }}
          >
            <Text className="text-error text-xs font-medium">Excluir</Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <ScreenContainer className="px-4 pt-4">
      {/* Header */}
      <View className="mb-4">
        <Text className="text-3xl font-bold text-foreground mb-2">
          Clientes
        </Text>
        <Text className="text-sm text-muted">
          {clients.length} cliente(s) cadastrado(s)
        </Text>
      </View>

      {/* Search */}
      <View className="bg-surface rounded-xl px-4 py-3 mb-4 border border-border flex-row items-center">
        <IconSymbol name="magnifyingglass" size={20} color={colors.muted} />
        <TextInput
          className="flex-1 ml-2 text-foreground"
          placeholder="Buscar cliente..."
          placeholderTextColor={colors.muted}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      {/* Filters */}
      <View className="flex-row gap-2 mb-4">
        {(["all", "active", "expiring", "expired"] as FilterStatus[]).map(
          (status) => (
            <TouchableOpacity
              key={status}
              className={`px-3 py-2 rounded-lg ${
                filterStatus === status ? "bg-primary" : "bg-surface border border-border"
              }`}
              onPress={() => setFilterStatus(status)}
            >
              <Text
                className={`text-sm font-medium ${
                  filterStatus === status ? "text-white" : "text-foreground"
                }`}
              >
                {status === "all"
                  ? "Todos"
                  : status === "active"
                  ? "Ativos"
                  : status === "expiring"
                  ? "Vencendo"
                  : "Vencidos"}
              </Text>
            </TouchableOpacity>
          )
        )}
      </View>

      {/* Client List */}
      <FlatList
        data={filteredClients}
        renderItem={renderClient}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={{ paddingBottom: 100 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
        ListEmptyComponent={
          <View className="items-center py-12">
            <IconSymbol
              name="person.2.fill"
              size={48}
              color={colors.muted}
            />
            <Text className="text-muted text-center mt-4">
              {searchQuery
                ? "Nenhum cliente encontrado"
                : "Nenhum cliente cadastrado"}
            </Text>
            <Text className="text-muted text-center text-sm mt-1">
              Toque no botão + para adicionar
            </Text>
          </View>
        }
      />

      {/* FAB */}
      <TouchableOpacity
        className="absolute bottom-24 right-4 w-14 h-14 rounded-full items-center justify-center shadow-lg"
        style={{
          backgroundColor: colors.primary,
          elevation: 8,
        }}
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          setShowAddModal(true);
        }}
      >
        <IconSymbol name="plus.circle.fill" size={32} color="#fff" />
      </TouchableOpacity>

      <AddModal
        visible={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSuccess={() => loadClients()}
      />
    </ScreenContainer>
  );
}
