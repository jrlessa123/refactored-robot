import { ScrollView, Text, View, TouchableOpacity, Switch } from "react-native";
import { useColorScheme } from "@/hooks/use-color-scheme";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useAuth } from "@/hooks/use-auth";
import * as Haptics from "expo-haptics";

export default function SettingsScreen() {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    logout();
  };

  return (
    <ScreenContainer className="px-4 pt-4">
      <ScrollView contentContainerStyle={{ paddingBottom: 100 }}>
        <Text className="text-3xl font-bold text-foreground mb-6">
          Configurações
        </Text>

        {/* Informações do Usuário */}
        {user && (
          <View className="mb-6">
            <Text className="text-lg font-semibold text-foreground mb-3">
              Conta
            </Text>

            <View className="bg-surface rounded-2xl p-4 border border-border">
              <View className="flex-row items-center mb-3">
                <View className="w-12 h-12 rounded-full bg-primary items-center justify-center mr-3">
                  <Text className="text-white text-xl font-bold">
                    {user.name?.charAt(0).toUpperCase() || "U"}
                  </Text>
                </View>
                <View className="flex-1">
                  <Text className="text-base font-semibold text-foreground">
                    {user.name || "Usuário"}
                  </Text>
                  <Text className="text-sm text-muted">{user.email}</Text>
                </View>
              </View>

              <TouchableOpacity
                className="bg-error py-3 rounded-lg items-center active:opacity-70"
                onPress={handleLogout}
              >
                <Text className="text-white font-semibold">Sair da Conta</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Aparência */}
        <View className="mb-6">
          <Text className="text-lg font-semibold text-foreground mb-3">
            Aparência
          </Text>

          <View className="bg-surface rounded-2xl p-4 border border-border">
            <View className="flex-row items-center justify-between">
              <View className="flex-1">
                <Text className="text-base text-foreground font-medium">
                  Tema Escuro
                </Text>
                <Text className="text-sm text-muted">
                  Atualmente: {colorScheme === "dark" ? "Escuro" : "Claro"}
                </Text>
              </View>
              <Switch
                value={colorScheme === "dark"}
                onValueChange={(value) => {
                  // Theme switching is handled by system
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                }}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor="#fff"
              />
            </View>
          </View>
        </View>

        {/* Notificações */}
        <View className="mb-6">
          <Text className="text-lg font-semibold text-foreground mb-3">
            Notificações
          </Text>

          <View className="bg-surface rounded-2xl p-4 border border-border">
            <View className="flex-row items-center justify-between mb-4">
              <View className="flex-1">
                <Text className="text-base text-foreground font-medium">
                  Alertas de Vencimento
                </Text>
                <Text className="text-sm text-muted">
                  Notificar quando clientes estiverem próximos ao vencimento
                </Text>
              </View>
              <Switch
                value={true}
                onValueChange={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                }}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor="#fff"
              />
            </View>

            <View className="border-t border-border pt-4">
              <Text className="text-sm text-muted mb-2">
                Dias de antecedência para alertas
              </Text>
              <View className="flex-row gap-2">
                {[3, 7, 15, 30].map((days) => (
                  <TouchableOpacity
                    key={days}
                    className="flex-1 py-2 rounded-lg border border-primary items-center active:opacity-70"
                    style={{ backgroundColor: days === 7 ? colors.primary : "transparent" }}
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    }}
                  >
                    <Text
                      className="text-sm font-medium"
                      style={{ color: days === 7 ? "#fff" : colors.primary }}
                    >
                      {days}d
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </View>
        </View>

        {/* Sobre */}
        <View className="mb-6">
          <Text className="text-lg font-semibold text-foreground mb-3">
            Sobre
          </Text>

          <View className="bg-surface rounded-2xl p-4 border border-border">
            <View className="flex-row items-center justify-between py-3 border-b border-border">
              <Text className="text-base text-foreground">Versão</Text>
              <Text className="text-sm text-muted">1.0.0</Text>
            </View>

            <View className="flex-row items-center justify-between py-3">
              <Text className="text-base text-foreground">
                Gerenciador de Clientes
              </Text>
              <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
            </View>
          </View>
        </View>

        {/* Informações Adicionais */}
        <View className="bg-primary/10 rounded-2xl p-4 border border-primary/20 mb-6">
          <Text className="text-sm text-foreground mb-2">
            📊 <Text className="font-semibold">Dica:</Text>
          </Text>
          <Text className="text-sm text-foreground leading-relaxed">
            Mantenha seus dados sempre atualizados para obter relatórios precisos
            e projeções confiáveis do seu negócio.
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
