import { useState, useCallback } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from "react-native";
import { useLocalSearchParams, useRouter, useFocusEffect } from "expo-router";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import * as LocalStore from "@/lib/local-store";

export default function ClientDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const colors = useColors();
  const [client, setClient] = useState<LocalStore.Client | null>(null);
  const [payments, setPayments] = useState<LocalStore.PaymentRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadData = useCallback(async () => {
    if (!id) return;
    try {
      const clientData = await LocalStore.getClientById(parseInt(id));
      const paymentsData = await LocalStore.getPaymentsByClientId(parseInt(id));
      setClient(clientData);
      setPayments(paymentsData);
    } catch (error) {
      console.error("Error loading client:", error);
    } finally {
      setIsLoading(false);
    }
  }, [id]);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData])
  );

  const handleRenew = async (plan: "monthly" | "semestral" | "annual") => {
    if (!client) return;
    const planDays: Record<string, number> = {
      monthly: 30,
      semestral: 180,
      annual: 365,
    };
    const newDate = new Date();
    newDate.setDate(newDate.getDate() + planDays[plan]);

    await LocalStore.renewClient(client.id, planDays[plan] / 30);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert("Sucesso", "Cliente renovado com sucesso!");
    loadData();
  };

  const handleDelete = () => {
    if (!client) return;
    Alert.alert(
      "Excluir Cliente",
      `Tem certeza que deseja excluir ${client.name}?`,
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Excluir",
          style: "destructive",
          onPress: async () => {
            await LocalStore.deleteClient(client.id);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            router.back();
          },
        },
      ]
    );
  };

  const formatDate = (date: Date) => new Date(date).toLocaleDateString("pt-BR");
  const formatCurrency = (value: string) =>
    new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
      parseFloat(value) || 0
    );

  const getStatus = () => {
    if (!client) return { label: "", color: colors.muted };
    const now = new Date();
    const expDate = new Date(client.expirationDate);
    const days = Math.ceil((expDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    if (days < 0) return { label: "Vencido", color: colors.error };
    if (days <= 7) return { label: "Vencendo", color: colors.warning };
    return { label: "Ativo", color: colors.success };
  };

  if (isLoading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color={colors.primary} />
      </ScreenContainer>
    );
  }

  if (!client) {
    return (
      <ScreenContainer className="items-center justify-center px-4">
        <Text className="text-foreground text-lg">Cliente não encontrado</Text>
        <TouchableOpacity
          className="mt-4 bg-primary px-6 py-3 rounded-lg"
          onPress={() => router.back()}
        >
          <Text className="text-white font-semibold">Voltar</Text>
        </TouchableOpacity>
      </ScreenContainer>
    );
  }

  const status = getStatus();

  return (
    <ScreenContainer className="px-4 pt-4">
      <ScrollView className="flex-1" contentContainerStyle={{ paddingBottom: 100 }}>
        {/* Header */}
        <View className="flex-row items-center mb-6">
          <TouchableOpacity
            className="mr-3 p-2"
            onPress={() => router.back()}
          >
            <IconSymbol name="chevron.left" size={24} color={colors.foreground} />
          </TouchableOpacity>
          <View className="flex-1">
            <Text className="text-2xl font-bold text-foreground">{client.name}</Text>
            <Text className="text-muted">{client.server}</Text>
          </View>
          <View
            className="px-3 py-1 rounded-full"
            style={{ backgroundColor: status.color + "20" }}
          >
            <Text className="text-sm font-medium" style={{ color: status.color }}>
              {status.label}
            </Text>
          </View>
        </View>

        {/* Info Card */}
        <View className="bg-surface rounded-xl p-4 mb-4 border border-border">
          <Text className="text-foreground font-semibold mb-3">Informações</Text>
          <View className="gap-2">
            <View className="flex-row justify-between">
              <Text className="text-muted">Tipo</Text>
              <Text className="text-foreground font-medium">{client.clientType}</Text>
            </View>
            <View className="flex-row justify-between">
              <Text className="text-muted">Telas</Text>
              <Text className="text-foreground font-medium">{client.screenCount}</Text>
            </View>
            <View className="flex-row justify-between">
              <Text className="text-muted">Custo Mensal</Text>
              <Text className="text-foreground font-medium">
                {formatCurrency(client.monthlyCost)}
              </Text>
            </View>
            <View className="flex-row justify-between">
              <Text className="text-muted">Cadastro</Text>
              <Text className="text-foreground font-medium">
                {formatDate(client.registrationDate)}
              </Text>
            </View>
            <View className="flex-row justify-between">
              <Text className="text-muted">Vencimento</Text>
              <Text className="font-medium" style={{ color: status.color }}>
                {formatDate(client.expirationDate)}
              </Text>
            </View>
          </View>
        </View>

        {/* Renew Card */}
        <View className="bg-surface rounded-xl p-4 mb-4 border border-border">
          <Text className="text-foreground font-semibold mb-3">Renovar</Text>
          <View className="flex-row gap-2">
            {[
              { value: "monthly", label: "Mensal" },
              { value: "semestral", label: "Semestral" },
              { value: "annual", label: "Anual" },
            ].map((plan) => (
              <TouchableOpacity
                key={plan.value}
                className="flex-1 bg-primary/10 py-3 rounded-lg items-center"
                onPress={() => handleRenew(plan.value as any)}
              >
                <Text className="text-primary font-semibold">{plan.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Payment History */}
        <View className="bg-surface rounded-xl p-4 mb-4 border border-border">
          <Text className="text-foreground font-semibold mb-3">Histórico</Text>
          {payments.length > 0 ? (
            payments.map((payment) => (
              <View
                key={payment.id}
                className="flex-row justify-between py-2 border-b border-border"
              >
                <Text className="text-muted">{formatDate(payment.paymentDate)}</Text>
                <Text className="text-foreground font-medium">
                  {formatCurrency(payment.amount)}
                </Text>
              </View>
            ))
          ) : (
            <Text className="text-muted text-center py-4">Nenhum histórico</Text>
          )}
        </View>

        {/* Delete Button */}
        <TouchableOpacity
          className="bg-error/10 py-4 rounded-xl items-center border border-error/30"
          onPress={handleDelete}
        >
          <Text className="text-error font-semibold">Excluir Cliente</Text>
        </TouchableOpacity>
      </ScrollView>
    </ScreenContainer>
  );
}
