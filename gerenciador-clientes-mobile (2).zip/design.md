# Design do Aplicativo - Gerenciador de Clientes

## Visão Geral
Aplicativo móvel para gerenciamento de clientes com foco em controle financeiro, servidores e relatórios. Design minimalista e profissional seguindo as diretrizes do iOS (Apple HIG).

## Orientação
- **Mobile portrait (9:16)** - uso com uma mão
- Navegação por tabs na parte inferior
- Design limpo e funcional

## Paleta de Cores
- **Primary (Azul profissional)**: #0a7ea4 - Representa confiabilidade e tecnologia
- **Success (Verde)**: #22C55E - Para indicadores positivos de lucro
- **Warning (Amarelo)**: #F59E0B - Para alertas de vencimento próximo
- **Error (Vermelho)**: #EF4444 - Para clientes vencidos
- **Background**: #ffffff (light) / #151718 (dark)
- **Surface**: #f5f5f5 (light) / #1e2022 (dark) - Cards e superfícies elevadas

## Lista de Telas

### 1. Home (Dashboard Financeiro)
**Conteúdo:**
- Cards com métricas principais:
  - Total de clientes ativos
  - Receita mensal recorrente (MRR)
  - Projeção de lucro do mês
  - Clientes próximos ao vencimento
- Gráfico de receita mensal (últimos 6 meses)
- Lista rápida de clientes recentes

**Funcionalidade:**
- Visualização rápida do status financeiro
- Navegação para detalhes ao tocar nos cards
- Pull-to-refresh para atualizar dados

### 2. Clientes (Lista)
**Conteúdo:**
- Lista de todos os clientes com cards mostrando:
  - Nome do cliente
  - Servidor associado
  - Status (ativo/vencido/próximo ao vencimento)
  - Data de vencimento
  - Valor mensal
- Barra de busca no topo
- Botão flutuante (+) para adicionar novo cliente

**Funcionalidade:**
- Busca por nome ou servidor
- Filtros por status (ativo/vencido)
- Ordenação por nome, data de vencimento ou valor
- Swipe para ações rápidas (editar/excluir)
- Tocar no card abre detalhes do cliente

### 3. Adicionar/Editar Cliente (Modal)
**Conteúdo:**
- Formulário com campos:
  - Nome do cliente (texto)
  - Servidor (texto ou seleção)
  - Custo mensal (número com R$)
  - Data de cadastro (date picker)
  - Data de vencimento (date picker)
  - Quantidade de telas (número)
  - Observações (textarea opcional)
- Botões: Cancelar / Salvar

**Funcionalidade:**
- Validação de campos obrigatórios
- Cálculo automático de próximo vencimento
- Feedback visual de erros

### 4. Detalhes do Cliente
**Conteúdo:**
- Header com nome e status visual
- Seções organizadas:
  - **Informações Gerais**: servidor, datas, quantidade de telas
  - **Financeiro**: custo mensal, total pago, próximo vencimento
  - **Histórico**: lista de pagamentos/renovações
- Botões de ação: Editar / Renovar / Excluir

**Funcionalidade:**
- Visualização completa dos dados
- Renovação rápida (atualiza data de vencimento)
- Confirmação antes de excluir

### 5. Relatórios
**Conteúdo:**
- Seletor de período (mês/trimestre/ano)
- Cards com análises:
  - Receita total do período
  - Lucro projetado
  - Taxa de renovação
  - Clientes por servidor
- Gráficos:
  - Evolução da receita (linha)
  - Distribuição por servidor (pizza)
  - Previsão de receita futura (linha pontilhada)
- Botão para exportar relatório

**Funcionalidade:**
- Filtros de período dinâmicos
- Cálculos automáticos de projeções
- Visualizações interativas

### 6. Configurações
**Conteúdo:**
- Preferências do app:
  - Tema (claro/escuro/automático)
  - Notificações de vencimento
  - Dias de antecedência para alertas
- Sobre o app
- Versão

**Funcionalidade:**
- Alternar tema
- Configurar lembretes

## Fluxos Principais

### Fluxo 1: Adicionar Novo Cliente
1. Usuário toca no botão (+) na tela de Clientes
2. Modal de formulário aparece
3. Usuário preenche os dados obrigatórios
4. Toca em "Salvar"
5. Cliente é adicionado à lista
6. Feedback de sucesso (toast)
7. Retorna à lista de clientes

### Fluxo 2: Visualizar Dashboard Financeiro
1. Usuário abre o app (tela Home)
2. Dashboard carrega métricas atualizadas
3. Usuário visualiza cards com resumo financeiro
4. Pode tocar em qualquer métrica para ver detalhes
5. Pull-to-refresh para atualizar dados

### Fluxo 3: Renovar Cliente
1. Usuário navega para Detalhes do Cliente
2. Toca no botão "Renovar"
3. Sistema atualiza data de vencimento (+30 dias)
4. Registra no histórico
5. Feedback de sucesso
6. Dados atualizados na tela

### Fluxo 4: Consultar Relatórios
1. Usuário acessa tab "Relatórios"
2. Seleciona período desejado
3. Visualiza gráficos e métricas calculadas
4. Pode alternar entre diferentes visualizações
5. Opcionalmente exporta relatório

## Navegação (Tab Bar)

- **Home** (ícone: house.fill) - Dashboard financeiro
- **Clientes** (ícone: person.2.fill) - Lista de clientes
- **Relatórios** (ícone: chart.bar.fill) - Análises e projeções
- **Configurações** (ícone: gearshape.fill) - Preferências

## Componentes Reutilizáveis

1. **ClientCard**: Card para exibir cliente na lista
2. **MetricCard**: Card para métricas do dashboard
3. **StatusBadge**: Badge colorido para status do cliente
4. **ChartContainer**: Container para gráficos
5. **FormInput**: Input customizado para formulários
6. **ActionButton**: Botão primário com feedback tátil

## Considerações de UX

- **Feedback Visual**: Todos os botões têm feedback de toque (scale + opacity)
- **Haptics**: Ações importantes (salvar, excluir) têm feedback tátil
- **Loading States**: Indicadores de carregamento para operações assíncronas
- **Empty States**: Mensagens amigáveis quando não há dados
- **Confirmações**: Ações destrutivas (excluir) requerem confirmação
- **Validação**: Feedback imediato em formulários
- **Acessibilidade**: Contraste adequado e tamanhos de toque mínimos (44x44pt)

## Dados e Armazenamento

Como o app requer sincronização de dados financeiros e histórico, utilizaremos o **backend com banco de dados PostgreSQL** para:
- Persistência confiável dos dados
- Histórico de transações
- Cálculos de relatórios complexos
- Backup automático

O backend já está disponível no projeto e será configurado na próxima fase.
