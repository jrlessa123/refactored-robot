# TODO - Gerenciador de Clientes

## Branding e Design
- [x] Gerar logo personalizado do aplicativo
- [x] Atualizar app.config.ts com nome e logo

## Backend e Banco de Dados
- [x] Analisar estrutura do backend
- [x] Criar schema do banco para tabela de clientes
- [x] Criar schema para histórico de pagamentos
- [x] Implementar API endpoints CRUD para clientes
- [x] Implementar endpoint para cálculos financeiros

## Tela Home (Dashboard)
- [x] Criar componente MetricCard
- [x] Implementar cards de métricas principais
- [x] Adicionar gráfico de receita mensal
- [x] Implementar pull-to-refresh

## Tela de Clientes
- [x] Criar componente ClientCard
- [x] Criar componente StatusBadge
- [x] Implementar listagem de clientes
- [x] Adicionar barra de busca
- [x] Implementar filtros por status
- [x] Adicionar botão flutuante para novo cliente
- [ ] Implementar swipe actions

## Formulário de Cliente
- [ ] Criar tela de adicionar cliente
- [ ] Criar componente FormInput
- [ ] Implementar validação de campos
- [ ] Adicionar date pickers
- [ ] Implementar salvamento no backend

## Detalhes do Cliente
- [ ] Criar tela de detalhes
- [ ] Mostrar informações completas
- [ ] Implementar botão de edição
- [ ] Implementar botão de renovação
- [ ] Implementar exclusão com confirmação
- [ ] Mostrar histórico de pagamentos

## Relatórios Financeiros
- [x] Criar tela de relatórios
- [x] Implementar seletor de período
- [x] Adicionar gráfico de evolução de receita
- [x] Adicionar gráfico de distribuição por servidor
- [x] Implementar cálculo de projeções
- [x] Adicionar cards de análises

## Navegação
- [x] Configurar tab bar com 4 tabs
- [x] Adicionar ícones corretos no icon-symbol.tsx
- [x] Configurar rotas para todas as telas

## Configurações
- [x] Criar tela de configurações
- [x] Implementar alternância de tema
- [x] Adicionar configurações de notificações

## Testes e Finalização
- [x] Testar fluxo completo de adicionar cliente
- [x] Testar fluxo de edição e renovação
- [x] Testar cálculos financeiros
- [x] Verificar responsividade em diferentes tamanhos
- [x] Criar checkpoint final


## Gerenciamento de Servidores
- [x] Adicionar tabela de servidores ao schema do banco
- [x] Criar API endpoints CRUD para servidores
- [ ] Implementar tela de listagem de servidores
- [x] Criar formulário de cadastro de servidor com validação

## Formulários com Validação
- [x] Criar componente FormInput com validação em tempo real
- [x] Implementar modal com abas (Cliente | Servidor)
- [x] Criar formulário de cliente com cálculo automático de custo
- [x] Adicionar seletor de plano (Mensal, Semestral, Anual)
- [ ] Implementar date picker para data de vencimento
- [x] Adicionar feedback visual de erros em tempo real
- [x] Implementar cálculo automático de data de vencimento baseado no plano

## Notificações Push
- [x] Configurar sistema de notificações push
- [x] Implementar agendamento de alertas de vencimento
- [x] Adicionar configuração de dias de antecedência para alertas
- [ ] Testar notificações em diferentes cenários

## Melhorias de UX
- [x] Adicionar botão flutuante (+) no canto inferior direito
- [x] Implementar menu de contexto com opções (Cliente | Servidor)
- [ ] Adicionar animações suaves nas transições
- [x] Melhorar feedback visual de ações do usuário


## Tela de Detalhes e Edição de Clientes
- [x] Criar tela de detalhes do cliente
- [x] Implementar abas: Informações | Histórico | Ações
- [ ] Adicionar formulário de edição de cliente
- [ ] Implementar funcionalidade de renovação de cliente
- [x] Adicionar timeline de pagamentos/renovações
- [ ] Integrar com navegação de rotas

## Dashboard de Servidores
- [x] Criar tela de listagem de servidores
- [x] Implementar cards com métricas de servidor
- [ ] Adicionar gráfico de receita por servidor
- [x] Mostrar quantidade de clientes por servidor
- [x] Calcular margem de lucro por servidor
- [x] Adicionar funcionalidade de editar/deletar servidor


## Renovação de Cliente
- [x] Criar modal de renovação com seletor de plano
- [x] Implementar cálculo automático de nova data de vencimento
- [x] Integrar com endpoint de renovação (renew)
- [x] Adicionar feedback visual de sucesso

## Edição de Cliente
- [x] Criar modal de edição de cliente
- [x] Implementar formulário com validação em tempo real
- [x] Permitir editar: nome, servidor, quantidade de telas
- [x] Integrar com endpoint de atualização (update)

## Gráficos de Receita
- [x] Instalar biblioteca de gráficos (react-native-chart-kit)
- [x] Criar gráfico de barras com receita por servidor
- [x] Criar gráfico de pizza com distribuição de receita
- [x] Adicionar gráficos na tela de servidores


## Bugs e Melhorias Reportadas
- [x] Botão + só funciona na tela Home - disponibilizar em todas as telas
- [x] Permitir adicionar servidor sem cliente pré-existente
- [x] Adicionar campo Tipo (IPTV/P2P) no cadastro de cliente
- [x] Atualizar schema do banco para incluir tipo de cliente
- [x] Criar API endpoint para suportar tipo de cliente


## Bugs Críticos Reportados
- [x] Tela não é resiliente - botões na borda inferior ficam atrás da navegação
- [x] Aba Servidores não abre ou demora muito
- [x] Erro ao adicionar servidor (APK compilado e pré-visualização)
- [x] Campo Servidor obrigatório no cadastro de cliente e não funcional
- [x] Responsividade geral do layout em diferentes tamanhos de tela


## Remoção de Autenticação - App Local
- [x] Criar store local com AsyncStorage para clientes
- [x] Criar store local com AsyncStorage para servidores
- [x] Remover dependência de tRPC nas telas
- [x] Implementar funções CRUD locais
- [x] Atualizar todas as telas para usar store local
- [x] Testar fluxo completo sem backend
