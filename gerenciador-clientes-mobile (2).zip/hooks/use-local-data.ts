import { useState, useEffect, useCallback } from "react";
import * as LocalStore from "@/lib/local-store";

export function useServers() {
  const [servers, setServers] = useState<LocalStore.Server[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const refetch = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await LocalStore.getServers();
      setServers(data);
    } catch (error) {
      console.error("Error fetching servers:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refetch();
  }, [refetch]);

  return { servers, isLoading, refetch };
}

export function useClients() {
  const [clients, setClients] = useState<LocalStore.Client[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const refetch = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await LocalStore.getClients();
      setClients(data);
    } catch (error) {
      console.error("Error fetching clients:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refetch();
  }, [refetch]);

  return { clients, isLoading, refetch };
}

export function useClient(id: number) {
  const [client, setClient] = useState<LocalStore.Client | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const refetch = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await LocalStore.getClientById(id);
      setClient(data);
    } catch (error) {
      console.error("Error fetching client:", error);
    } finally {
      setIsLoading(false);
    }
  }, [id]);

  useEffect(() => {
    refetch();
  }, [refetch]);

  return { client, isLoading, refetch };
}

export function usePayments(clientId: number) {
  const [payments, setPayments] = useState<LocalStore.PaymentRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const refetch = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await LocalStore.getPaymentsByClientId(clientId);
      setPayments(data);
    } catch (error) {
      console.error("Error fetching payments:", error);
    } finally {
      setIsLoading(false);
    }
  }, [clientId]);

  useEffect(() => {
    refetch();
  }, [refetch]);

  return { payments, isLoading, refetch };
}

export function useDashboardStats() {
  const [stats, setStats] = useState({
    totalActiveClients: 0,
    monthlyRecurringRevenue: 0,
    expiringThisWeek: 0,
    expiredClients: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  const refetch = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await LocalStore.getDashboardStats();
      setStats(data);
    } catch (error) {
      console.error("Error fetching stats:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refetch();
  }, [refetch]);

  return { stats, isLoading, refetch };
}

export function useClientsByServer() {
  const [data, setData] = useState<
    { server: string; count: number; totalRevenue: number; totalCost: number; profit: number }[]
  >([]);
  const [isLoading, setIsLoading] = useState(true);

  const refetch = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await LocalStore.getClientsByServer();
      setData(result);
    } catch (error) {
      console.error("Error fetching clients by server:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refetch();
  }, [refetch]);

  return { data, isLoading, refetch };
}
