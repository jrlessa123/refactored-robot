import { useEffect } from "react";
import { requestNotificationPermissions } from "@/lib/notifications";

export function useNotifications() {
  useEffect(() => {
    const initializeNotifications = async () => {
      await requestNotificationPermissions();
    };

    initializeNotifications();
  }, []);
}
