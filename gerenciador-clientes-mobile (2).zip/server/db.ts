import { and, desc, eq, gte, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { clients, servers, paymentHistory, InsertUser, users, type InsertClient, type Server, type InsertServer, type InsertPaymentHistory } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============= Client Functions =============

/**
 * Get all clients for a user
 */
export async function getUserClients(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(clients).where(eq(clients.userId, userId)).orderBy(desc(clients.createdAt));
}

/**
 * Get a single client by ID
 */
export async function getClientById(clientId: number, userId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db
    .select()
    .from(clients)
    .where(and(eq(clients.id, clientId), eq(clients.userId, userId)))
    .limit(1);
  
  return result[0] || null;
}

/**
 * Create a new client
 */
export async function createClient(data: InsertClient) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const [result] = await db.insert(clients).values(data);
  return Number(result.insertId);
}

/**
 * Update a client
 */
export async function updateClient(clientId: number, userId: number, data: Partial<InsertClient>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db
    .update(clients)
    .set({ ...data, updatedAt: new Date() })
    .where(and(eq(clients.id, clientId), eq(clients.userId, userId)));
}

/**
 * Delete a client
 */
export async function deleteClient(clientId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(clients).where(and(eq(clients.id, clientId), eq(clients.userId, userId)));
}

/**
 * Get clients expiring soon (within specified days)
 */
export async function getExpiringClients(userId: number, daysAhead: number = 7) {
  const db = await getDb();
  if (!db) return [];
  
  const now = new Date();
  const futureDate = new Date();
  futureDate.setDate(futureDate.getDate() + daysAhead);
  
  return db
    .select()
    .from(clients)
    .where(
      and(
        eq(clients.userId, userId),
        eq(clients.isActive, true),
        gte(clients.expirationDate, now),
        lte(clients.expirationDate, futureDate)
      )
    )
    .orderBy(clients.expirationDate);
}

/**
 * Get expired clients
 */
export async function getExpiredClients(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const now = new Date();
  
  return db
    .select()
    .from(clients)
    .where(
      and(
        eq(clients.userId, userId),
        eq(clients.isActive, true),
        lte(clients.expirationDate, now)
      )
    )
    .orderBy(clients.expirationDate);
}

// ============= Payment History Functions =============

/**
 * Get payment history for a client
 */
export async function getClientPaymentHistory(clientId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select()
    .from(paymentHistory)
    .where(eq(paymentHistory.clientId, clientId))
    .orderBy(desc(paymentHistory.paymentDate));
}

/**
 * Add payment record
 */
export async function addPaymentRecord(data: InsertPaymentHistory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const [result] = await db.insert(paymentHistory).values(data);
  return Number(result.insertId);
}

/**
 * Renew client (update expiration date and add payment record)
 */
export async function renewClient(
  clientId: number,
  userId: number,
  renewalMonths: number = 1
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Get current client
  const client = await getClientById(clientId, userId);
  if (!client) throw new Error("Client not found");
  
  // Calculate new expiration date
  const currentExpiration = new Date(client.expirationDate);
  const newExpiration = new Date(currentExpiration);
  newExpiration.setMonth(newExpiration.getMonth() + renewalMonths);
  
  // Update client expiration
  await updateClient(clientId, userId, {
    expirationDate: newExpiration,
    isActive: true,
  });
  
  // Add payment record
  const amount = parseFloat(client.monthlyCost) * renewalMonths;
  await addPaymentRecord({
    clientId,
    amount: amount.toString(),
    paymentDate: new Date(),
    previousExpirationDate: currentExpiration,
    newExpirationDate: newExpiration,
    notes: `Renovação de ${renewalMonths} ${renewalMonths === 1 ? 'mês' : 'meses'}`,
  });
  
  return { newExpiration };
}

// ============= Financial Analytics Functions =============

/**
 * Get total monthly recurring revenue (MRR)
 */
export async function getMonthlyRecurringRevenue(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  
  const result = await db
    .select({
      total: sql<number>`COALESCE(SUM(${clients.monthlyCost}), 0)`,
    })
    .from(clients)
    .where(and(eq(clients.userId, userId), eq(clients.isActive, true)));
  
  return result[0]?.total || 0;
}

/**
 * Get revenue for a specific month
 */
export async function getMonthlyRevenue(userId: number, year: number, month: number) {
  const db = await getDb();
  if (!db) return 0;
  
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0, 23, 59, 59);
  
  const result = await db
    .select({
      total: sql<number>`COALESCE(SUM(${paymentHistory.amount}), 0)`,
    })
    .from(paymentHistory)
    .innerJoin(clients, eq(paymentHistory.clientId, clients.id))
    .where(
      and(
        eq(clients.userId, userId),
        gte(paymentHistory.paymentDate, startDate),
        lte(paymentHistory.paymentDate, endDate)
      )
    );
  
  return result[0]?.total || 0;
}

/**
 * Get client distribution by server
 */
export async function getClientsByServer(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db
    .select({
      server: clients.server,
      count: sql<number>`COUNT(*)`,
      totalRevenue: sql<number>`COALESCE(SUM(${clients.monthlyCost}), 0)`,
    })
    .from(clients)
    .where(and(eq(clients.userId, userId), eq(clients.isActive, true)))
    .groupBy(clients.server);
  
  return result;
}

/**
 * Get dashboard statistics
 */
export async function getDashboardStats(userId: number) {
  const db = await getDb();
  if (!db) {
    return {
      totalActiveClients: 0,
      monthlyRecurringRevenue: 0,
      expiringThisWeek: 0,
      expiredClients: 0,
    };
  }
  
  const now = new Date();
  const weekFromNow = new Date();
  weekFromNow.setDate(weekFromNow.getDate() + 7);
  
  // Total active clients
  const activeResult = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(clients)
    .where(and(eq(clients.userId, userId), eq(clients.isActive, true)));
  
  // MRR
  const mrrResult = await db
    .select({ total: sql<number>`COALESCE(SUM(${clients.monthlyCost}), 0)` })
    .from(clients)
    .where(and(eq(clients.userId, userId), eq(clients.isActive, true)));
  
  // Expiring this week
  const expiringResult = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(clients)
    .where(
      and(
        eq(clients.userId, userId),
        eq(clients.isActive, true),
        gte(clients.expirationDate, now),
        lte(clients.expirationDate, weekFromNow)
      )
    );
  
  // Expired clients
  const expiredResult = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(clients)
    .where(
      and(
        eq(clients.userId, userId),
        eq(clients.isActive, true),
        lte(clients.expirationDate, now)
      )
    );
  
  return {
    totalActiveClients: activeResult[0]?.count || 0,
    monthlyRecurringRevenue: mrrResult[0]?.total || 0,
    expiringThisWeek: expiringResult[0]?.count || 0,
    expiredClients: expiredResult[0]?.count || 0,
  };
}

/**
 * Get revenue history for the last N months
 */
export async function getRevenueHistory(userId: number, months: number = 6) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db
    .select({
      month: sql<string>`DATE_FORMAT(${paymentHistory.paymentDate}, '%Y-%m')`,
      revenue: sql<number>`COALESCE(SUM(${paymentHistory.amount}), 0)`,
    })
    .from(paymentHistory)
    .innerJoin(clients, eq(paymentHistory.clientId, clients.id))
    .where(eq(clients.userId, userId))
    .groupBy(sql`DATE_FORMAT(${paymentHistory.paymentDate}, '%Y-%m')`)
    .orderBy(sql`DATE_FORMAT(${paymentHistory.paymentDate}, '%Y-%m') DESC`)
    .limit(months);
  
  return result.reverse();
}


// ============= Server Functions =============

export async function getUserServers(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(servers).where(eq(servers.userId, userId)).orderBy(desc(servers.createdAt));
}

export async function getServerById(serverId: number, userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(servers)
    .where(and(eq(servers.id, serverId), eq(servers.userId, userId)))
    .limit(1);
  return result[0] || null;
}

export async function createServer(data: InsertServer) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [result] = await db.insert(servers).values(data);
  return Number(result.insertId);
}

export async function updateServer(serverId: number, userId: number, data: Partial<InsertServer>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(servers)
    .set({ ...data, updatedAt: new Date() })
    .where(and(eq(servers.id, serverId), eq(servers.userId, userId)));
}

export async function deleteServer(serverId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(servers).where(and(eq(servers.id, serverId), eq(servers.userId, userId)));
}
