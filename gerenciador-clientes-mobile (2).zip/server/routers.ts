import { z } from "zod";
import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Server management routes
  servers: router({
    list: protectedProcedure.query(({ ctx }) => {
      return db.getUserServers(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ ctx, input }) => {
        return db.getServerById(input.id, ctx.user.id);
      }),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1).max(255),
          costPerClient: z.string().regex(/^\d+(\.\d{1,2})?$/),
          description: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const serverId = await db.createServer({
          userId: ctx.user.id,
          ...input,
        });
        return { id: serverId };
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().min(1).max(255).optional(),
          costPerClient: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
          description: z.string().optional(),
          isActive: z.boolean().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        await db.updateServer(id, ctx.user.id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteServer(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  // Client management routes
  clients: router({
    // List all clients
    list: protectedProcedure.query(({ ctx }) => {
      return db.getUserClients(ctx.user.id);
    }),

    // Get single client
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ ctx, input }) => {
        return db.getClientById(input.id, ctx.user.id);
      }),

    // Create client
    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1).max(255),
          server: z.string().min(1).max(255),
          clientType: z.enum(["IPTV", "P2P"]).default("IPTV"),
          monthlyCost: z.string().regex(/^\d+(\.\d{1,2})?$/),
          registrationDate: z.date(),
          expirationDate: z.date(),
          screenCount: z.number().int().min(0),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const clientId = await db.createClient({
          userId: ctx.user.id,
          ...input,
        });
        return { id: clientId };
      }),

    // Update client
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().min(1).max(255).optional(),
          server: z.string().min(1).max(255).optional(),
          monthlyCost: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
          registrationDate: z.date().optional(),
          expirationDate: z.date().optional(),
          screenCount: z.number().int().min(0).optional(),
          notes: z.string().optional(),
          isActive: z.boolean().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        await db.updateClient(id, ctx.user.id, data);
        return { success: true };
      }),

    // Delete client
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteClient(input.id, ctx.user.id);
        return { success: true };
      }),

    // Get expiring clients
    expiring: protectedProcedure
      .input(z.object({ daysAhead: z.number().int().min(1).max(90).default(7) }))
      .query(({ ctx, input }) => {
        return db.getExpiringClients(ctx.user.id, input.daysAhead);
      }),

    // Get expired clients
    expired: protectedProcedure.query(({ ctx }) => {
      return db.getExpiredClients(ctx.user.id);
    }),

    // Renew client
    renew: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          renewalMonths: z.number().int().min(1).max(12).default(1),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const result = await db.renewClient(input.id, ctx.user.id, input.renewalMonths);
        return result;
      }),
  }),

  // Payment history routes
  payments: router({
    // Get payment history for a client
    history: protectedProcedure
      .input(z.object({ clientId: z.number() }))
      .query(({ input }) => {
        return db.getClientPaymentHistory(input.clientId);
      }),
  }),

  // Financial analytics routes
  analytics: router({
    // Get dashboard statistics
    dashboard: protectedProcedure.query(({ ctx }) => {
      return db.getDashboardStats(ctx.user.id);
    }),

    // Get monthly recurring revenue
    mrr: protectedProcedure.query(({ ctx }) => {
      return db.getMonthlyRecurringRevenue(ctx.user.id);
    }),

    // Get revenue for specific month
    monthlyRevenue: protectedProcedure
      .input(
        z.object({
          year: z.number().int().min(2020).max(2100),
          month: z.number().int().min(1).max(12),
        })
      )
      .query(({ ctx, input }) => {
        return db.getMonthlyRevenue(ctx.user.id, input.year, input.month);
      }),

    // Get clients by server
    byServer: protectedProcedure.query(({ ctx }) => {
      return db.getClientsByServer(ctx.user.id);
    }),

    // Get revenue history
    revenueHistory: protectedProcedure
      .input(z.object({ months: z.number().int().min(1).max(24).default(6) }))
      .query(({ ctx, input }) => {
        return db.getRevenueHistory(ctx.user.id, input.months);
      }),
  }),
});

export type AppRouter = typeof appRouter;
