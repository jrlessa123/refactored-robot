import { View, Text, TextInput, type TextInputProps } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { cn } from "@/lib/utils";

interface FormInputProps extends TextInputProps {
  label?: string;
  error?: string;
  helperText?: string;
  containerClassName?: string;
}

export function FormInput({
  label,
  error,
  helperText,
  containerClassName,
  className,
  placeholderTextColor,
  ...props
}: FormInputProps) {
  const colors = useColors();

  return (
    <View className={cn("mb-4", containerClassName)}>
      {label && (
        <Text className="text-sm font-semibold text-foreground mb-2">
          {label}
        </Text>
      )}

      <TextInput
        className={cn(
          "bg-surface rounded-lg px-4 py-3 text-foreground border",
          error ? "border-error" : "border-border",
          className
        )}
        placeholderTextColor={placeholderTextColor || colors.muted}
        {...props}
      />

      {error && (
        <Text className="text-xs text-error mt-1">{error}</Text>
      )}

      {helperText && !error && (
        <Text className="text-xs text-muted mt-1">{helperText}</Text>
      )}
    </View>
  );
}
