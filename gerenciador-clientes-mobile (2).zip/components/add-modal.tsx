import { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  Modal,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
  Platform,
  TextInput,
} from "react-native";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/use-colors";
import { FormInput } from "./form-input";
import * as LocalStore from "@/lib/local-store";

interface AddModalProps {
  visible: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

type Tab = "client" | "server";

// Helper functions for date formatting
const formatDateToBR = (date: Date): string => {
  const day = String(date.getDate()).padStart(2, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
};

const parseBRDate = (dateStr: string): Date | null => {
  try {
    const parts = dateStr.split("/");
    if (parts.length !== 3) return null;
    const day = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);
    const year = parseInt(parts[2], 10);

    if (day < 1 || day > 31 || month < 1 || month > 12 || year < 1900 || year > 2100) {
      return null;
    }

    const date = new Date(year, month - 1, day);
    if (date.getDate() !== day || date.getMonth() !== month - 1) {
      return null;
    }
    return date;
  } catch {
    return null;
  }
};

export function AddModal({ visible, onClose, onSuccess }: AddModalProps) {
  const colors = useColors();
  const [activeTab, setActiveTab] = useState<Tab>("client");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [servers, setServers] = useState<LocalStore.Server[]>([]);

  const today = new Date();
  const defaultRegistrationDate = formatDateToBR(today);
  const defaultExpirationDate = formatDateToBR(
    new Date(today.getFullYear(), today.getMonth() + 1, today.getDate())
  );

  const [clientForm, setClientForm] = useState({
    name: "",
    serverId: "",
    clientType: "IPTV" as "IPTV" | "P2P",
    plan: "monthly" as "monthly" | "semestral" | "annual",
    screenCount: "",
    registrationDate: defaultRegistrationDate,
    expirationDate: defaultExpirationDate,
    notes: "",
  });

  const [serverForm, setServerForm] = useState({
    name: "",
    costPerClient: "",
    description: "",
  });

  useEffect(() => {
    if (visible) {
      loadServers();
    }
  }, [visible]);

  const loadServers = async () => {
    try {
      const data = await LocalStore.getServers();
      setServers(data);
    } catch (error) {
      console.error("Error loading servers:", error);
    }
  };

  const calculateExpirationDate = (registrationDateStr: string) => {
    const regDate = parseBRDate(registrationDateStr);
    if (!regDate) return clientForm.expirationDate;

    const expDate = new Date(regDate);
    const monthsToAdd: Record<LocalStore.PlanType, number> = {
      monthly: 1,
      semestral: 6,
      annual: 12,
    };
    expDate.setMonth(expDate.getMonth() + monthsToAdd[clientForm.plan]);
    return formatDateToBR(expDate);
  };

  const validateClientForm = () => {
    const newErrors: Record<string, string> = {};
    if (!clientForm.name.trim()) newErrors.name = "Nome é obrigatório";
    if (!clientForm.serverId) newErrors.serverId = "Servidor é obrigatório";
    if (!clientForm.screenCount) newErrors.screenCount = "Quantidade de telas é obrigatória";
    if (parseInt(clientForm.screenCount) <= 0)
      newErrors.screenCount = "Deve ser maior que 0";

    const regDate = parseBRDate(clientForm.registrationDate);
    if (!regDate) newErrors.registrationDate = "Data inválida (DD/MM/AAAA)";

    const expDate = parseBRDate(clientForm.expirationDate);
    if (!expDate) newErrors.expirationDate = "Data inválida (DD/MM/AAAA)";

    if (regDate && expDate && regDate >= expDate) {
      newErrors.expirationDate = "Data de vencimento deve ser após cadastro";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateServerForm = () => {
    const newErrors: Record<string, string> = {};
    if (!serverForm.name.trim()) newErrors.name = "Nome é obrigatório";
    if (!serverForm.costPerClient) newErrors.costPerClient = "Custo é obrigatório";
    if (parseFloat(serverForm.costPerClient) <= 0)
      newErrors.costPerClient = "Deve ser maior que 0";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAddClient = async () => {
    if (!validateClientForm()) return;
    setIsLoading(true);
    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      const selectedServer = clientForm.serverId
        ? servers.find((s) => s.id === parseInt(clientForm.serverId))
        : null;

      const regDate = parseBRDate(clientForm.registrationDate);
      const expDate = parseBRDate(clientForm.expirationDate);

      if (!regDate || !expDate) {
        Alert.alert("Erro", "Datas inválidas");
        return;
      }

      await LocalStore.createClient(
        clientForm.name,
        selectedServer?.name || "Sem servidor",
        clientForm.clientType,
        clientForm.plan,
        parseInt(clientForm.screenCount),
        regDate,
        expDate,
        clientForm.notes
      );

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert("Sucesso", "Cliente adicionado com sucesso!");
      resetForms();
      onClose();
      onSuccess?.();
    } catch (error) {
      console.error("Error adding client:", error);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert("Erro", "Falha ao adicionar cliente");
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddServer = async () => {
    if (!validateServerForm()) return;
    setIsLoading(true);
    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

      await LocalStore.createServer(
        serverForm.name,
        serverForm.costPerClient,
        serverForm.description
      );

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert("Sucesso", "Servidor adicionado com sucesso!");
      resetForms();
      await loadServers();
      onClose();
      onSuccess?.();
    } catch (error) {
      console.error("Error adding server:", error);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert("Erro", "Falha ao adicionar servidor");
    } finally {
      setIsLoading(false);
    }
  };

  const resetForms = () => {
    const today = new Date();
    const defaultRegDate = formatDateToBR(today);
    const defaultExpDate = formatDateToBR(
      new Date(today.getFullYear(), today.getMonth() + 1, today.getDate())
    );

    setClientForm({
      name: "",
      serverId: "",
      clientType: "IPTV",
      plan: "monthly",
      screenCount: "",
      registrationDate: defaultRegDate,
      expirationDate: defaultExpDate,
      notes: "",
    });
    setServerForm({
      name: "",
      costPerClient: "",
      description: "",
    });
    setErrors({});
  };

  const handlePlanChange = (newPlan: LocalStore.PlanType) => {
    setClientForm((prev) => ({
      ...prev,
      plan: newPlan,
      expirationDate: calculateExpirationDate(prev.registrationDate),
    }));
  };

  const handleRegistrationDateChange = (text: string) => {
    setClientForm((prev) => ({
      ...prev,
      registrationDate: text,
      expirationDate: calculateExpirationDate(text),
    }));
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View className="flex-1 bg-black/50">
        <View
          className="flex-1 bg-background rounded-t-3xl mt-auto"
          style={{
            paddingBottom: Platform.OS === "android" ? 20 : 0,
          }}
        >
          {/* Tab Selector */}
          <View className="flex-row border-b border-border">
            <TouchableOpacity
              className={`flex-1 py-4 items-center ${
                activeTab === "client" ? "border-b-2" : ""
              }`}
              style={{
                borderBottomColor: activeTab === "client" ? colors.primary : "transparent",
              }}
              onPress={() => setActiveTab("client")}
            >
              <Text
                className={`font-semibold ${
                  activeTab === "client" ? "text-primary" : "text-muted"
                }`}
              >
                Cliente
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              className={`flex-1 py-4 items-center ${
                activeTab === "server" ? "border-b-2" : ""
              }`}
              style={{
                borderBottomColor: activeTab === "server" ? colors.primary : "transparent",
              }}
              onPress={() => setActiveTab("server")}
            >
              <Text
                className={`font-semibold ${
                  activeTab === "server" ? "text-primary" : "text-muted"
                }`}
              >
                Servidor
              </Text>
            </TouchableOpacity>
          </View>

          {/* Content */}
          {activeTab === "client" ? (
            <ScrollView
              className="flex-1 p-6"
              contentContainerStyle={{ paddingBottom: 100 }}
            >
              <FormInput
                label="Nome do Cliente"
                placeholder="Ex: João Silva"
                value={clientForm.name}
                onChangeText={(text) =>
                  setClientForm((prev) => ({ ...prev, name: text }))
                }
                error={errors.name}
              />

              <View className="mb-4">
                <Text className="text-sm font-semibold text-foreground mb-2">
                  Servidor *
                </Text>
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  className="gap-2"
                >
                  {servers.length > 0 ? (
                    servers.map((server) => (
                      <TouchableOpacity
                        key={server.id}
                        className={`px-4 py-2 rounded-lg border ${
                          clientForm.serverId === server.id.toString()
                            ? "bg-primary border-primary"
                            : "bg-surface border-border"
                        }`}
                        onPress={() =>
                          setClientForm((prev) => ({
                            ...prev,
                            serverId: server.id.toString(),
                          }))
                        }
                      >
                        <Text
                          className={
                            clientForm.serverId === server.id.toString()
                              ? "text-white font-semibold"
                              : "text-foreground"
                          }
                        >
                          {server.name}
                        </Text>
                      </TouchableOpacity>
                    ))
                  ) : (
                    <Text className="text-muted">Nenhum servidor cadastrado</Text>
                  )}
                </ScrollView>
                {errors.serverId && (
                  <Text className="text-xs text-error mt-1">{errors.serverId}</Text>
                )}
              </View>

              <View className="mb-4">
                <Text className="text-sm font-semibold text-foreground mb-2">
                  Tipo de Cliente
                </Text>
                <View className="flex-row gap-2">
                  {(["IPTV", "P2P"] as const).map((type) => (
                    <TouchableOpacity
                      key={type}
                      className={`flex-1 py-2 rounded-lg border ${
                        clientForm.clientType === type
                          ? "bg-primary border-primary"
                          : "bg-surface border-border"
                      }`}
                      onPress={() =>
                        setClientForm((prev) => ({ ...prev, clientType: type }))
                      }
                    >
                      <Text
                        className={
                          clientForm.clientType === type
                            ? "text-white font-semibold text-center"
                            : "text-foreground text-center"
                        }
                      >
                        {type}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View className="mb-4">
                <Text className="text-sm font-semibold text-foreground mb-2">
                  Plano (Receita Mensal) *
                </Text>
                <View className="gap-2">
                  {(
                    [
                      {
                        value: "monthly",
                        label: "Mensal",
                        price: LocalStore.PLAN_PRICES.monthly,
                      },
                      {
                        value: "semestral",
                        label: "Semestral",
                        price: LocalStore.PLAN_PRICES.semestral,
                      },
                      {
                        value: "annual",
                        label: "Anual",
                        price: LocalStore.PLAN_PRICES.annual,
                      },
                    ] as const
                  ).map((p) => (
                    <TouchableOpacity
                      key={p.value}
                      className={`py-3 px-4 rounded-lg border ${
                        clientForm.plan === p.value
                          ? "bg-primary border-primary"
                          : "bg-surface border-border"
                      }`}
                      onPress={() => handlePlanChange(p.value)}
                    >
                      <Text
                        className={
                          clientForm.plan === p.value
                            ? "text-white font-semibold"
                            : "text-foreground"
                        }
                      >
                        {p.label} - R$ {p.price.toFixed(2)}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <FormInput
                label="Quantidade de Telas *"
                placeholder="Ex: 1"
                value={clientForm.screenCount}
                onChangeText={(text) =>
                  setClientForm((prev) => ({ ...prev, screenCount: text }))
                }
                keyboardType="number-pad"
                error={errors.screenCount}
              />

              <View className="mb-4">
                <Text className="text-sm font-semibold text-foreground mb-2">
                  Data de Cadastro (DD/MM/AAAA) *
                </Text>
                <TextInput
                  className="px-4 py-3 rounded-lg border border-border bg-surface text-foreground"
                  placeholder="03/02/2026"
                  value={clientForm.registrationDate}
                  onChangeText={handleRegistrationDateChange}
                  maxLength={10}
                />
                {errors.registrationDate && (
                  <Text className="text-xs text-error mt-1">
                    {errors.registrationDate}
                  </Text>
                )}
              </View>

              <View className="mb-4">
                <Text className="text-sm font-semibold text-foreground mb-2">
                  Data de Vencimento (DD/MM/AAAA) *
                </Text>
                <TextInput
                  className="px-4 py-3 rounded-lg border border-border bg-surface text-foreground"
                  placeholder="03/03/2026"
                  value={clientForm.expirationDate}
                  onChangeText={(text) =>
                    setClientForm((prev) => ({ ...prev, expirationDate: text }))
                  }
                  maxLength={10}
                />
                {errors.expirationDate && (
                  <Text className="text-xs text-error mt-1">
                    {errors.expirationDate}
                  </Text>
                )}
              </View>

              <FormInput
                label="Observações (opcional)"
                placeholder="Notas adicionais..."
                value={clientForm.notes}
                onChangeText={(text) =>
                  setClientForm((prev) => ({ ...prev, notes: text }))
                }
                multiline
              />

              <TouchableOpacity
                className="bg-primary py-4 rounded-xl items-center mt-6 mb-4"
                onPress={handleAddClient}
                disabled={isLoading}
              >
                {isLoading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text className="text-white font-bold text-lg">
                    Salvar Cliente
                  </Text>
                )}
              </TouchableOpacity>
            </ScrollView>
          ) : (
            <ScrollView
              className="flex-1 p-6"
              contentContainerStyle={{ paddingBottom: 100 }}
            >
              <FormInput
                label="Nome do Servidor"
                placeholder="Ex: Servidor 1"
                value={serverForm.name}
                onChangeText={(text) =>
                  setServerForm((prev) => ({ ...prev, name: text }))
                }
                error={errors.name}
              />

              <FormInput
                label="Custo por Cliente (R$) *"
                placeholder="Ex: 6.00"
                value={serverForm.costPerClient}
                onChangeText={(text) =>
                  setServerForm((prev) => ({ ...prev, costPerClient: text }))
                }
                keyboardType="decimal-pad"
                error={errors.costPerClient}
              />

              <FormInput
                label="Descrição (opcional)"
                placeholder="Notas sobre o servidor..."
                value={serverForm.description}
                onChangeText={(text) =>
                  setServerForm((prev) => ({ ...prev, description: text }))
                }
                multiline
              />

              <TouchableOpacity
                className="bg-success py-4 rounded-xl items-center mt-6 mb-4"
                onPress={handleAddServer}
                disabled={isLoading}
              >
                {isLoading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text className="text-white font-bold text-lg">
                    Salvar Servidor
                  </Text>
                )}
              </TouchableOpacity>
            </ScrollView>
          )}
        </View>
      </View>
    </Modal>
  );
}
