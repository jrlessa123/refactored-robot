import { View, Text } from "react-native";
import { useColors } from "@/hooks/use-colors";

interface ServerData {
  server: string;
  count: number;
  totalRevenue: number;
}

interface ServerChartsProps {
  data: ServerData[];
}

export function ServerCharts({ data }: ServerChartsProps) {
  const colors = useColors();

  if (!data || data.length === 0) {
    return null;
  }

  // Calculate total revenue for percentage
  const totalRevenue = data.reduce((sum) => sum + data[0].totalRevenue, 0);
  const maxRevenue = Math.max(...data.map((s) => s.totalRevenue));

  const chartColors = [
    colors.primary,
    colors.success,
    colors.warning,
    colors.error,
    "#8B5CF6",
    "#EC4899",
  ];

  return (
    <View className="gap-6 mb-6">
      {/* Bar Chart - Receita por Servidor */}
      <View className="bg-surface rounded-2xl p-4 border border-border">
        <Text className="text-lg font-bold text-foreground mb-4">
          Receita por Servidor
        </Text>
        <View className="gap-3">
          {data.map((server, index) => {
            const percentage = (server.totalRevenue / maxRevenue) * 100;
            return (
              <View key={index}>
                <View className="flex-row items-center justify-between mb-1">
                  <Text className="text-sm font-medium text-foreground">
                    {server.server}
                  </Text>
                  <Text className="text-sm font-bold text-foreground">
                    R$ {server.totalRevenue.toFixed(2)}
                  </Text>
                </View>
                <View className="h-6 bg-border rounded-full overflow-hidden">
                  <View
                    className="h-full rounded-full"
                    style={{
                      width: `${percentage}%`,
                      backgroundColor: chartColors[index % 6],
                    }}
                  />
                </View>
              </View>
            );
          })}
        </View>
      </View>

      {/* Pizza Chart - Distribuição de Receita (usando barras circulares) */}
      <View className="bg-surface rounded-2xl p-4 border border-border">
        <Text className="text-lg font-bold text-foreground mb-4">
          Distribuição de Receita
        </Text>
        <View className="items-center mb-4">
          <View className="flex-row flex-wrap justify-center gap-2">
            {data.map((server, index) => {
              const percentage = ((server.totalRevenue / totalRevenue) * 100).toFixed(1);
              return (
                <View
                  key={index}
                  className="items-center"
                  style={{ width: "48%" }}
                >
                  <View
                    className="w-16 h-16 rounded-full items-center justify-center mb-2"
                    style={{
                      backgroundColor: chartColors[index % 6] + "20",
                      borderWidth: 2,
                      borderColor: chartColors[index % 6],
                    }}
                  >
                    <Text className="text-xs font-bold text-foreground">
                      {percentage}%
                    </Text>
                  </View>
                  <Text className="text-xs text-center text-muted">
                    {server.server.substring(0, 10)}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>
      </View>

      {/* Legenda de Receita */}
      <View className="bg-surface rounded-2xl p-4 border border-border">
        <Text className="text-lg font-bold text-foreground mb-3">
          Resumo por Servidor
        </Text>
        <View className="gap-2">
          {data.map((server, index) => (
            <View key={index} className="flex-row items-center justify-between">
              <View className="flex-row items-center flex-1">
                <View
                  className="w-3 h-3 rounded-full mr-2"
                  style={{
                    backgroundColor: chartColors[index % 6],
                  }}
                />
                <Text className="text-sm font-medium text-foreground flex-1">
                  {server.server}
                </Text>
              </View>
              <View className="items-end">
                <Text className="text-sm font-bold text-foreground">
                  R$ {server.totalRevenue.toFixed(2)}
                </Text>
                <Text className="text-xs text-muted">
                  {server.count} cliente{server.count !== 1 ? "s" : ""}
                </Text>
              </View>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
}
