import AsyncStorage from "@react-native-async-storage/async-storage";

// Types
export type PlanType = "monthly" | "semestral" | "annual";

// Plan prices (fixed)
export const PLAN_PRICES: Record<PlanType, number> = {
  monthly: 30,
  semestral: 165,
  annual: 300,
};

export interface Server {
  id: number;
  name: string;
  costPerClient: string;
  description?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Client {
  id: number;
  name: string;
  server: string;
  clientType: "IPTV" | "P2P";
  plan: PlanType;
  monthlyCost: string;
  registrationDate: Date;
  expirationDate: Date;
  screenCount: number;
  notes?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface PaymentRecord {
  id: number;
  clientId: number;
  amount: string;
  paymentDate: Date;
  previousExpirationDate: Date;
  newExpirationDate: Date;
  notes?: string;
  createdAt: Date;
}

export interface DashboardStats {
  totalActiveClients: number;
  monthlyRecurringRevenue: number;
  monthlyRecurringCost: number;
  monthlyNetProfit: number;
  expiringThisWeek: number;
  expiredClients: number;
  costsPerServer: { name: string; cost: number }[];
}

const STORAGE_KEYS = {
  SERVERS: "@gerenciador_servers",
  CLIENTS: "@gerenciador_clients",
  PAYMENTS: "@gerenciador_payments",
  NEXT_IDS: "@gerenciador_next_ids",
};

// Helper to get next ID
async function getNextId(type: "server" | "client" | "payment"): Promise<number> {
  try {
    const idsJson = await AsyncStorage.getItem(STORAGE_KEYS.NEXT_IDS);
    const ids = idsJson ? JSON.parse(idsJson) : { server: 0, client: 0, payment: 0 };
    ids[type] = (ids[type] || 0) + 1;
    await AsyncStorage.setItem(STORAGE_KEYS.NEXT_IDS, JSON.stringify(ids));
    return ids[type];
  } catch (error) {
    console.error("Error getting next ID:", error);
    return Math.floor(Math.random() * 100000);
  }
}

// Server Functions
export async function createServer(
  name: string,
  costPerClient: string,
  description?: string
): Promise<Server> {
  try {
    const servers = await getServers();
    const id = await getNextId("server");
    const now = new Date();
    const server: Server = {
      id,
      name,
      costPerClient,
      description,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    };
    servers.push(server);
    await AsyncStorage.setItem(STORAGE_KEYS.SERVERS, JSON.stringify(servers));
    return server;
  } catch (error) {
    console.error("Error creating server:", error);
    throw error;
  }
}

export async function getServers(): Promise<Server[]> {
  try {
    const data = await AsyncStorage.getItem(STORAGE_KEYS.SERVERS);
    return data
      ? JSON.parse(data).map((s: any) => ({
          ...s,
          createdAt: new Date(s.createdAt),
          updatedAt: new Date(s.updatedAt),
        }))
      : [];
  } catch (error) {
    console.error("Error getting servers:", error);
    return [];
  }
}

export async function deleteServer(id: number): Promise<void> {
  try {
    const servers = await getServers();
    const filtered = servers.filter((s) => s.id !== id);
    await AsyncStorage.setItem(STORAGE_KEYS.SERVERS, JSON.stringify(filtered));
  } catch (error) {
    console.error("Error deleting server:", error);
    throw error;
  }
}

// Client Functions
export async function createClient(
  name: string,
  server: string,
  clientType: "IPTV" | "P2P",
  plan: PlanType,
  screenCount: number,
  registrationDate: Date,
  expirationDate: Date,
  notes?: string
): Promise<Client> {
  try {
    const clients = await getClients();
    const servers = await getServers();
    const serverData = servers.find((s) => s.name === server);
    const monthlyCost = serverData?.costPerClient || "0";

    const id = await getNextId("client");
    const now = new Date();
    const client: Client = {
      id,
      name,
      server,
      clientType,
      plan,
      monthlyCost,
      screenCount,
      registrationDate,
      expirationDate,
      notes,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    };
    clients.push(client);
    await AsyncStorage.setItem(STORAGE_KEYS.CLIENTS, JSON.stringify(clients));
    return client;
  } catch (error) {
    console.error("Error creating client:", error);
    throw error;
  }
}

export async function getClients(): Promise<Client[]> {
  try {
    const data = await AsyncStorage.getItem(STORAGE_KEYS.CLIENTS);
    return data
      ? JSON.parse(data).map((c: any) => ({
          ...c,
          registrationDate: new Date(c.registrationDate),
          expirationDate: new Date(c.expirationDate),
          createdAt: new Date(c.createdAt),
          updatedAt: new Date(c.updatedAt),
        }))
      : [];
  } catch (error) {
    console.error("Error getting clients:", error);
    return [];
  }
}

export async function getClientById(id: number): Promise<Client | null> {
  try {
    const clients = await getClients();
    return clients.find((c) => c.id === id) || null;
  } catch (error) {
    console.error("Error getting client by ID:", error);
    return null;
  }
}

export async function updateClient(id: number, updates: Partial<Client>): Promise<Client | null> {
  try {
    const clients = await getClients();
    const index = clients.findIndex((c) => c.id === id);
    if (index === -1) return null;
    clients[index] = { ...clients[index], ...updates, updatedAt: new Date() };
    await AsyncStorage.setItem(STORAGE_KEYS.CLIENTS, JSON.stringify(clients));
    return clients[index];
  } catch (error) {
    console.error("Error updating client:", error);
    return null;
  }
}

export async function deleteClient(id: number): Promise<void> {
  try {
    const clients = await getClients();
    const filtered = clients.filter((c) => c.id !== id);
    await AsyncStorage.setItem(STORAGE_KEYS.CLIENTS, JSON.stringify(filtered));

    // Also delete associated payments
    const payments = await getPaymentsByClientId(id);
    for (const payment of payments) {
      await deletePayment(payment.id);
    }
  } catch (error) {
    console.error("Error deleting client:", error);
    throw error;
  }
}

export async function renewClient(clientId: number, months: number): Promise<Client | null> {
  try {
    const client = await getClientById(clientId);
    if (!client) return null;

    const newExpirationDate = new Date(client.expirationDate);
    newExpirationDate.setMonth(newExpirationDate.getMonth() + months);

    // Record payment - use plan price
    const planPrice = PLAN_PRICES[client.plan];
    await createPayment(
      clientId,
      planPrice.toString(),
      new Date(),
      client.expirationDate,
      newExpirationDate
    );

    return updateClient(clientId, { expirationDate: newExpirationDate });
  } catch (error) {
    console.error("Error renewing client:", error);
    return null;
  }
}

// Payment Functions
export async function createPayment(
  clientId: number,
  amount: string,
  paymentDate: Date,
  previousExpirationDate: Date,
  newExpirationDate: Date,
  notes?: string
): Promise<PaymentRecord> {
  try {
    const payments = await getPayments();
    const id = await getNextId("payment");
    const payment: PaymentRecord = {
      id,
      clientId,
      amount,
      paymentDate,
      previousExpirationDate,
      newExpirationDate,
      notes,
      createdAt: new Date(),
    };
    payments.push(payment);
    await AsyncStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
    return payment;
  } catch (error) {
    console.error("Error creating payment:", error);
    throw error;
  }
}

export async function getPayments(): Promise<PaymentRecord[]> {
  try {
    const data = await AsyncStorage.getItem(STORAGE_KEYS.PAYMENTS);
    return data
      ? JSON.parse(data).map((p: any) => ({
          ...p,
          paymentDate: new Date(p.paymentDate),
          previousExpirationDate: new Date(p.previousExpirationDate),
          newExpirationDate: new Date(p.newExpirationDate),
          createdAt: new Date(p.createdAt),
        }))
      : [];
  } catch (error) {
    console.error("Error getting payments:", error);
    return [];
  }
}

export async function getPaymentsByClientId(clientId: number): Promise<PaymentRecord[]> {
  try {
    const payments = await getPayments();
    return payments.filter((p) => p.clientId === clientId);
  } catch (error) {
    console.error("Error getting payments by client ID:", error);
    return [];
  }
}

export async function deletePayment(id: number): Promise<void> {
  try {
    const payments = await getPayments();
    const filtered = payments.filter((p) => p.id !== id);
    await AsyncStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(filtered));
  } catch (error) {
    console.error("Error deleting payment:", error);
    throw error;
  }
}

// Dashboard Stats - LÓGICA DE LUCRO CORRIGIDA
export async function getDashboardStats(): Promise<DashboardStats> {
  try {
    const clients = await getClients();
    const servers = await getServers();
    const now = new Date();

    const activeClients = clients.filter((c) => c.expirationDate > now && c.isActive);
    const expiredClients = clients.filter((c) => c.expirationDate <= now);
    const expiringThisWeek = clients.filter((c) => {
      const daysUntilExpiration = Math.ceil(
        (c.expirationDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
      );
      return daysUntilExpiration > 0 && daysUntilExpiration <= 7;
    });

    let monthlyRecurringRevenue = 0;
    let monthlyRecurringCost = 0;

    activeClients.forEach((client) => {
      // Get the price from the plan (not from user input)
      const planPrice = PLAN_PRICES[client.plan];
      const cost = parseFloat(client.monthlyCost) || 0;

      // Calculate monthly revenue based on plan duration
      const planMonthlyRevenue: Record<PlanType, number> = {
        monthly: planPrice,
        semestral: planPrice / 6,
        annual: planPrice / 12,
      };

      monthlyRecurringRevenue += planMonthlyRevenue[client.plan];
      monthlyRecurringCost += cost;
    });

    // Calculate costs per server
    const costsPerServer = servers
      .map((server) => {
        const serverClients = activeClients.filter((c) => c.server === server.name);
        const totalCost = serverClients.length * (parseFloat(server.costPerClient) || 0);
        return { name: server.name, cost: totalCost };
      })
      .filter((item) => item.cost > 0); // Only show servers with costs

    return {
      totalActiveClients: activeClients.length,
      monthlyRecurringRevenue,
      monthlyRecurringCost,
      monthlyNetProfit: monthlyRecurringRevenue - monthlyRecurringCost,
      expiringThisWeek: expiringThisWeek.length,
      expiredClients: expiredClients.length,
      costsPerServer,
    };
  } catch (error) {
    console.error("Error getting dashboard stats:", error);
    return {
      totalActiveClients: 0,
      monthlyRecurringRevenue: 0,
      monthlyRecurringCost: 0,
      monthlyNetProfit: 0,
      expiringThisWeek: 0,
      expiredClients: 0,
      costsPerServer: [],
    };
  }
}

// Get clients by server with profit calculation
export async function getClientsByServer() {
  try {
    const clients = await getClients();
    const now = new Date();
    const activeClients = clients.filter((c) => c.expirationDate > now && c.isActive);

    const serverMap = new Map<
      string,
      {
        count: number;
        totalRevenue: number;
        totalCost: number;
        profit: number;
      }
    >();

    activeClients.forEach((client) => {
      const planPrice = PLAN_PRICES[client.plan];
      const cost = parseFloat(client.monthlyCost) || 0;

      const planMonthlyRevenue: Record<PlanType, number> = {
        monthly: planPrice,
        semestral: planPrice / 6,
        annual: planPrice / 12,
      };

      const monthlyRevenue = planMonthlyRevenue[client.plan];
      const monthlyProfit = monthlyRevenue - cost;

      if (!serverMap.has(client.server)) {
        serverMap.set(client.server, {
          count: 0,
          totalRevenue: 0,
          totalCost: 0,
          profit: 0,
        });
      }

      const server = serverMap.get(client.server)!;
      server.count++;
      server.totalRevenue += monthlyRevenue;
      server.totalCost += cost;
      server.profit += monthlyProfit;
    });

    return Array.from(serverMap.entries()).map(([server, data]) => ({
      server,
      ...data,
    }));
  } catch (error) {
    console.error("Error getting clients by server:", error);
    return [];
  }
}

// Clear all data (for testing)
export async function clearAllData(): Promise<void> {
  try {
    await AsyncStorage.removeItem(STORAGE_KEYS.SERVERS);
    await AsyncStorage.removeItem(STORAGE_KEYS.CLIENTS);
    await AsyncStorage.removeItem(STORAGE_KEYS.PAYMENTS);
    await AsyncStorage.removeItem(STORAGE_KEYS.NEXT_IDS);
  } catch (error) {
    console.error("Error clearing data:", error);
    throw error;
  }
}
