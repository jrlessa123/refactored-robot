// This file is kept for compatibility but TRPC is not used in this offline-first app
// All data is stored locally using AsyncStorage

export const trpc = null;

export function createTRPCClient() {
  return null;
}
