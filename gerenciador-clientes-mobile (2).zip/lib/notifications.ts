import AsyncStorage from "@react-native-async-storage/async-storage";

export async function requestNotificationPermissions() {
  try {
    // Notifications are handled via AsyncStorage on local app
    return true;
  } catch (error) {
    console.error("Error requesting notification permissions:", error);
    return false;
  }
}

export async function scheduleExpirationNotification(
  clientId: number,
  clientName: string,
  expirationDate: Date,
  daysAhead: number = 7
) {
  try {
    const notificationDate = new Date(expirationDate);
    notificationDate.setDate(notificationDate.getDate() - daysAhead);

    // Only schedule if the date is in the future
    if (notificationDate > new Date()) {
      // Store notification reminder in AsyncStorage
      const notificationIds = JSON.parse(
        (await AsyncStorage.getItem("notificationIds")) || "{}"
      );
      const notificationId = `${clientId}_${daysAhead}d_${Date.now()}`;
      notificationIds[`client_${clientId}_${daysAhead}d`] = notificationId;
      await AsyncStorage.setItem("notificationIds", JSON.stringify(notificationIds));

      return notificationId;
    }
  } catch (error) {
    console.error("Error scheduling notification:", error);
  }
}

export async function cancelExpirationNotification(
  clientId: number,
  daysAhead: number = 7
) {
  try {
    const notificationIds = JSON.parse(
      (await AsyncStorage.getItem("notificationIds")) || "{}"
    );
    const notificationId = notificationIds[`client_${clientId}_${daysAhead}d`];

    if (notificationId) {
      delete notificationIds[`client_${clientId}_${daysAhead}d`];
      await AsyncStorage.setItem("notificationIds", JSON.stringify(notificationIds));
    }
  } catch (error) {
    console.error("Error canceling notification:", error);
  }
}

export async function scheduleAllClientNotifications(clients: any[]) {
  try {
    const daysAheadOptions = [1, 3, 7]; // Notify 1, 3, and 7 days before expiration

    for (const client of clients) {
      if (client.isActive) {
        for (const daysAhead of daysAheadOptions) {
          await scheduleExpirationNotification(
            client.id,
            client.name,
            client.expirationDate,
            daysAhead
          );
        }
      }
    }
  } catch (error) {
    console.error("Error scheduling all notifications:", error);
  }
}

export async function cancelAllClientNotifications(clientId: number) {
  try {
    const daysAheadOptions = [1, 3, 7];
    for (const daysAhead of daysAheadOptions) {
      await cancelExpirationNotification(clientId, daysAhead);
    }
  } catch (error) {
    console.error("Error canceling all notifications:", error);
  }
}
